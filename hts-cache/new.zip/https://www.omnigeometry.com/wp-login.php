<!DOCTYPE html>
	<html lang="en-US">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; OmniGeometry &#8212; WordPress</title>
	<meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='https://www.omnigeometry.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-content/plugins/optimizePressPlugin/lib/js/op-jquery-base-all.min.js?ver=2.5.25' id='optimizepress-op-jquery-base-all-js'></script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.9' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-includes/js/dist/hooks.min.js?ver=c6d64f2cb8f5c6bb49caca37f8828ce3' id='wp-hooks-js'></script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-includes/js/dist/i18n.min.js?ver=ebee46757c6a411e38fd079a7ac71d94' id='wp-i18n-js'></script>
<script type='text/javascript' id='wp-i18n-js-after'>
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script type='text/javascript' id='zxcvbn-async-js-extra'>
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"https:\/\/www.omnigeometry.com\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-includes/js/zxcvbn-async.min.js?ver=1.0' id='zxcvbn-async-js'></script>
<script type='text/javascript' id='password-strength-meter-js-extra'>
/* <![CDATA[ */
var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-admin/js/password-strength-meter.min.js?ver=6.0' id='password-strength-meter-js'></script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-content/plugins/optimizeMember/optimizeMember-o.php?ws_plugin__optimizemember_js_w_globals=1&#038;qcABC=1&#038;ver=1.2.12-1.2.12-2616112252' id='ws-plugin--optimizemember-js'></script>
<link rel='stylesheet' id='dashicons-css'  href='https://www.omnigeometry.com/wp-includes/css/dashicons.min.css?ver=6.0' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='https://www.omnigeometry.com/wp-includes/css/buttons.min.css?ver=6.0' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='https://www.omnigeometry.com/wp-admin/css/forms.min.css?ver=6.0' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='https://www.omnigeometry.com/wp-admin/css/l10n.min.css?ver=6.0' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='https://www.omnigeometry.com/wp-admin/css/login.min.css?ver=6.0' type='text/css' media='all' />

<style type="text/css">
html, body { border:0 !important; background:none !important; }
html { background-color:#FFFFFF !important; }
html { background-image:url() !important; }
html { background-repeat:repeat !important; }
body, body * { font-size:12px !important; }
body, body * { font-family:'Verdana', 'Arial', sans-serif !important; }
div#login { width:631px !important; max-width: 100%; }
div#login h1 a { background:url(https://www.omnigeometry.com/wp-content/uploads/2017/03/OmniGeometry_login_logo.png) no-repeat top center !important; background-size:auto !important; }
div#login h1 a { display:block !important; width:100% !important; height:116px !important; }
div#login form { -moz-box-shadow:1px 1px 5px #EEEEEE, -1px -1px 5px #EEEEEE !important; -webkit-box-shadow:1px 1px 5px #EEEEEE, -1px -1px 5px #EEEEEE !important; box-shadow:1px 1px 5px #EEEEEE, -1px -1px 5px #EEEEEE !important; }
div#login p#nav, div#login p#nav a, div#login p#nav a:hover, div#login p#nav a:active, div#login p#nav a:focus { color:#000000 !important; text-shadow:1px 1px 3px #EEEEEE !important; }
div#login p#backtoblog, div#login p#backtoblog a, div#login p#backtoblog a:hover, div#login p#backtoblog a:active, div#login p#backtoblog a:focus { color:#000000 !important; text-shadow:1px 1px 3px #EEEEEE !important; }
div#login form p { margin:2px 0 16px 0 !important; }
div#login form input[type="text"], div#login form input[type="email"], div#login form input[type="password"], div#login form textarea, div#login form select { font-weight:normal !important; color:#333333 !important; background:none repeat scroll 0 0 #FBFBFB !important; border:1px solid #E5E5E5 !important; font-size:18px !important; margin:0 !important; padding:3px !important; -moz-border-radius:3px !important; -webkit-border-radius:3px !important; border-radius:3px !important; width:100% !important; width:98% !important !ie<8; margin-right:2% !important !ie<8; box-sizing:border-box !important; -ms-box-sizing:border-box !important; -moz-box-sizing:border-box !important; -webkit-box-sizing:border-box !important; }
div#login form select { width:99.5% !important !ie<8; } div#login form select > option { font-size:18px !important; }
div#login form label { cursor:pointer !important; } div#login form label.ws-plugin--optimizemember-custom-reg-field-op-l { opacity:0.7 !important; font-size:90% !important; vertical-align:middle !important; }
div#login form input[type="checkbox"], div#login form input[type="radio"] { margin:0 3px 0 0 !important; vertical-align:middle !important; }
div#login form input#ws-plugin--optimizemember-custom-reg-field-user-pass2[type="password"] { margin-top:5px !important; }
div#login form div.ws-plugin--optimizemember-custom-reg-field-divider-section { margin:2px 0 16px 0 !important; border:0 !important; height:1px !important; line-height:1px !important; background:#CCCCCC !important; }
div#login form div.ws-plugin--optimizemember-custom-reg-field-divider-section-title { margin:2px 0 16px 0 !important; border:0 solid #CCCCCC !important; border-width:0 0 1px 0 !important; padding:0 0 10px 0 !important; font-size:110% !important; }
div#login form input[type="submit"], div#login form input[type="submit"]:hover, div#login form input[type="submit"]:active, div#login form input[type="submit"]:focus { color:#666666 !important; text-shadow:2px 2px 5px #EEEEEE !important; border:1px solid #999999 !important; background:#FBFBFB !important; -moz-border-radius:3px !important; -webkit-border-radius:3px !important; border-radius:3px !important; }
div#login form input[type="submit"]:hover, div#login form input[type="submit"]:active, div#login form input[type="submit"]:focus { color:#000000 !important; text-shadow:2px 2px 5px #CCCCCC !important; border-color:#000000 !important; }
div#login form#registerform { padding-bottom:16px !important; } div#login form#registerform p.submit { float:none !important; margin-top:-10px !important; } div#login form#registerform input[type="submit"] { float:none !important; width:100% !important; width:98% !important !ie<8; margin-right:2% !important !ie<8; box-sizing:border-box !important; -ms-box-sizing:border-box !important; -moz-box-sizing:border-box !important; -webkit-box-sizing:border-box !important; }
div#login form#lostpasswordform { padding-bottom:16px !important; } div#login form#lostpasswordform p.submit { float:none !important; } div#login form#lostpasswordform input[type="submit"] { float:none !important; width:100% !important; width:98% !important !ie<8; margin-right:2% !important !ie<8; box-sizing:border-box !important; -ms-box-sizing:border-box !important; -moz-box-sizing:border-box !important; -webkit-box-sizing:border-box !important; }
div.ws-plugin--optimizemember-password-strength { margin-top:3px !important; font-color:#000000 !important; background-color:#EEEEEE !important; padding:3px !important; -moz-border-radius:3px !important; -webkit-border-radius:3px !important; border-radius:3px !important; } div.ws-plugin--optimizemember-password-strength-short { background-color:#FFA0A0 !important; } div.ws-plugin--optimizemember-password-strength-bad { background-color:#FFB78C !important; } div.ws-plugin--optimizemember-password-strength-good { background-color:#FFEC8B !important; } div.ws-plugin--optimizemember-password-strength-strong { background-color:#C3FF88 !important; } div.ws-plugin--optimizemember-password-strength-mismatch { background-color:#D6C1AB !important; }
div#login form#registerform p#reg_passmail { font-style:italic !important; }
</style>

	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
	<link rel="icon" href="https://www.omnigeometry.com/wp-content/uploads/2016/10/ms-icon-310x310-150x150-1.jpg" sizes="32x32" />
<link rel="icon" href="https://www.omnigeometry.com/wp-content/uploads/2016/10/ms-icon-310x310-300x300-1.jpg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.omnigeometry.com/wp-content/uploads/2016/10/ms-icon-310x310-300x300-1.jpg" />
<meta name="msapplication-TileImage" content="https://www.omnigeometry.com/wp-content/uploads/2016/10/ms-icon-310x310-300x300-1.jpg" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-en-us">
	<script type="text/javascript">
		document.body.className = document.body.className.replace('no-js','js');
	</script>
		<div id="login">
		<h1><a href="https://www.omnigeometry.com">OmniGeometry</a></h1>
	<div id="login_error">	Please log in again.<br />
</div>

		<form name="loginform" id="loginform" action="https://www.omnigeometry.com/wp-login.php" method="post">
			<p>
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="log" id="user_login" aria-describedby="login_error" class="input" value="" size="20" autocapitalize="off" autocomplete="username" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">My Password:</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" aria-describedby="login_error" class="input password-input" value="" size="20" autocomplete="current-password" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Remember Me</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
									<input type="hidden" name="redirect_to" value="https://www.omnigeometry.com/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
								<a href="https://www.omnigeometry.com/wp-login.php?action=lostpassword">Lost your password?</a>
			</p>
					<script type="text/javascript">
			function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }		</script>
				<p id="backtoblog">
			<a href="https://www.omnigeometry.com/">&larr; Go to OmniGeometry</a>		</p>
			</div>
			<script type='text/javascript' src='https://www.omnigeometry.com/wp-content/plugins/wishlist-member/ui/js/frontend.js?ver=3.14.8337' id='wlm3_js-js'></script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-includes/js/underscore.min.js?ver=1.13.3' id='underscore-js'></script>
<script type='text/javascript' id='wp-util-js-extra'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-includes/js/wp-util.min.js?ver=6.0' id='wp-util-js'></script>
<script type='text/javascript' id='user-profile-js-extra'>
/* <![CDATA[ */
var userProfileL10n = {"user_id":"0","nonce":"82fc753f3a"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.omnigeometry.com/wp-admin/js/user-profile.min.js?ver=6.0' id='user-profile-js'></script>
	<div class="clear"></div>
	</body>
	</html>
	